# ✦ SmartResume — AI Resume Intelligence System

> A fully-featured, production-ready AI resume analyzer. No backend, no database, no paid services required — runs 100% in your browser.

---

## 🐛 Bugs Fixed in This Version

| # | Bug | Fix Applied |
|---|-----|-------------|
| 1 | **No API key support** — app silently 401'd locally | Added API key modal with localStorage storage + `x-api-key` header |
| 2 | **Missing `anthropic-version` header** — required by API | Added `anthropic-version: 2023-06-01` to every request |
| 3 | **Nav tab active state broken** — index mapping was wrong | Rewrote nav using `data-page` attributes, single source of truth |
| 4 | **`showPage('results')` called before `unlockTabs()`** | Fixed order: unlock first, then navigate |
| 5 | **PDF upload promised, not implemented** | Removed PDF from accept; clearly documented `.txt` only |
| 6 | **Cover letter had hardcoded `[Candidate Name]`** | Added candidate name field; name flows into cover letter prompt |
| 7 | **History date formatting broken** | Fixed using `toLocaleString` with correct locale options |
| 8 | **Interview Qs persisted across analyses** | Reset on each new analysis run |
| 9 | **Cover letter persisted across analyses** | Reset on each new analysis run |
| 10 | **`toggleAll()` fragile querySelector** | Fixed with explicit `id="expand-btn"` |
| 11 | **No export/download feature** | Added `.txt` export for Results, Interview Qs, Cover Letter, History |
| 12 | **No demo data** | Added "Try Demo" button with realistic sample data |
| 13 | **No score trend chart** | Built pure-canvas chart showing last 12 scores over time |
| 14 | **No retry feedback on API errors** | Added specific messages for 401 (bad key), 429 (rate limit), etc. |
| 15 | **Loading steps cosmetically timed only** | Steps now tied to actual API lifecycle (start/stop) |
| 16 | **Individual history items not deletable** | Added ✕ delete button per history item |
| 17 | **Cover letter download missing** | Added `.txt` download + copy button |
| 18 | **XSS in interview Q rendering** | Fixed with `escHtml()` sanitization on all dynamic HTML |
| 19 | **No candidate name in cover letter** | Name + job title input fields added to analyzer page |
| 20 | **`resultGrid.` score arc circumference wrong** | Recalculated: r=52, circ=326.73 (was 301.59 for r=48) |

---

## ✨ Features (All Working)

| Feature | Status | Notes |
|---|---|---|
| 🔑 API Key Manager | ✅ | Secure modal, stored in localStorage, never sent anywhere except Anthropic |
| 🎯 ATS Match Score (0-100) | ✅ | Animated ring with color coding |
| 📊 Sub-scores | ✅ | Skills Match, Experience Fit, Keyword Coverage |
| 🔴 Missing Keywords | ✅ | Skills in JD absent from resume |
| 🟢 Present Keywords | ✅ | Skills in JD found in resume |
| ⚡ Skill Gap Priority Map | ✅ | Critical / Important / Nice-to-have tags |
| 💡 5 Improvement Suggestions | ✅ | Specific, section-level, actionable |
| ⭐ Strengths Identified | ✅ | What you already do well |
| 🤖 AI Career Coach Summary | ✅ | 4-5 honest sentences |
| 🎤 Interview Q Generator | ✅ | 10 tailored questions (Technical/Behavioral/Situational/Role) |
| ✉️ Cover Letter Generator | ✅ | 4 tones × 3 lengths, uses candidate's actual name |
| 📈 Score Trend Chart | ✅ | Pure canvas chart, no library needed |
| 📚 Analysis History | ✅ | Last 20 analyses, reload any result, delete individual items |
| 📥 Export Results | ✅ | Results as .txt, Interview Qs as .txt, Cover Letter as .txt, History as .txt |
| 🖨️ Print Results | ✅ | Browser print dialog |
| 🎮 Demo Mode | ✅ | One-click load with realistic sample data |
| 📎 File Upload | ✅ | .txt files for JD and resume |
| 👤 Candidate Name Field | ✅ | Flows into cover letter automatically |

---

## 🛠 Tech Stack (100% Free)

| Technology | Role | Cost |
|---|---|---|
| **Claude Sonnet 4** (Anthropic) | All AI analysis | $5 free credits on signup |
| **Vanilla HTML/CSS/JS** | Complete UI | Free |
| **Canvas API** | Score trend chart | Free (browser-native) |
| **localStorage** | History + API key | Free (browser-native) |
| **Google Fonts** | Syne + DM Sans + DM Mono | Free |
| **No backend** | Zero server needed | Free |
| **No npm/node** | No build step | N/A |

---

## ⚡ Installation & Running

### Option 1 — Local Server (Recommended)

```bash
# Clone the repo
git clone https://github.com/Suraj-Aher/smart-resume-analyzer.git
cd smart-resume-analyzer

# Python 3 (no install needed)
python -m http.server 8080

# Open in browser
open http://localhost:8080
# Windows: start http://localhost:8080
# Linux:   xdg-open http://localhost:8080
```

**OR with Node.js:**
```bash
npx serve .
# Opens at http://localhost:3000
```

**OR with VS Code:**
- Install "Live Server" extension
- Right-click `index.html` → Open with Live Server

> ⚠️ **Important:** Do NOT open `index.html` directly as `file://`. The Anthropic API requires `http://` or `https://` due to CORS. Always use a local server.

---

### Option 2 — GitHub Pages (Free Hosting, No Server Needed)

```bash
# 1. Create repo on GitHub: smart-resume-analyzer

# 2. Push your code
git init
git add .
git commit -m "feat: SmartResume AI Analyzer v2"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/smart-resume-analyzer.git
git push -u origin main

# 3. Enable GitHub Pages:
#    Settings → Pages → Source: Deploy from branch → main → / (root) → Save

# 4. Live at: https://YOUR_USERNAME.github.io/smart-resume-analyzer
```

---

### Option 3 — Netlify Drop (Instant, No Account Needed)

1. Go to [netlify.com/drop](https://app.netlify.com/drop)
2. Drag your `smart-resume-analyzer/` folder onto the page
3. Get a live URL in 10 seconds

---

## 🔑 API Key Setup

1. Visit [console.anthropic.com](https://console.anthropic.com) and sign up (free)
2. Go to API Keys → Create Key
3. Copy the key (`sk-ant-api03-...`)
4. In the app, click **"Set API Key"** in the top-right nav
5. Paste your key and click Save

**Free tier:** $5 credits on signup ≈ **800–1,600 analyses**
**Cost per analysis:** ~$0.003–0.006 (Claude Sonnet 4)

> Your API key is stored only in your browser's `localStorage`. It is never sent anywhere except directly to `api.anthropic.com`.

---

## 📁 Project Structure

```
smart-resume-analyzer/
├── index.html     ← Complete application (single file, ~2100 lines)
└── README.md      ← This file
```

---

## 🧩 How the AI Pipeline Works

```
User Input (JD + Resume)
      │
      ▼
Input Validation + Sanitization
      │
      ▼
Prompt Engineering (structured JSON schema)
  ├── Role priming: "ATS expert + career coach"
  ├── Explicit field definitions with constraints
  ├── Hard output rules (no markdown, pure JSON)
  └── Honesty anchoring ("90+ only for near-perfect")
      │
      ▼
Claude Sonnet 4 API Call
  └── Headers: Content-Type + x-api-key + anthropic-version
      │
      ▼
Robust JSON Parsing (strips fences, finds bounds)
      │
      ▼
Render Results (animated ring, bars, keyword clouds)
      │
      ├── [Optional] Interview Q API call (separate)
      └── [Optional] Cover Letter API call (separate)
      │
      ▼
Save to localStorage history (up to 20 items)
      │
      ▼
Score Trend Chart (pure canvas, no library)
```

---

## 💡 Prompt Engineering Decisions

| Technique | Why |
|---|---|
| Role priming first | Sets the model's evaluation framework before seeing data |
| Explicit JSON schema with field-level constraints | Prevents hallucination, controls output shape |
| `missing_keywords: 6-14 items` range constraint | Prevents both under- and over-generation |
| Separate prompts for interview Qs and cover letter | Keeps each prompt focused; reduces hallucination |
| Honesty anchoring for score | Without this, Claude tends to be overly generous |
| Candidate name injected into cover letter prompt | Eliminates placeholder text like `[Your Name]` |
| `escHtml()` on all dynamic DOM insertions | Prevents XSS from AI-generated content |

---

## 🔧 Troubleshooting

| Problem | Solution |
|---|---|
| "Invalid API key" error | Click "Set API Key" and re-enter your `sk-ant-...` key |
| "Rate limit" error | Wait 30-60 seconds and retry |
| CORS error in console | Use a local server (`python -m http.server 8080`), not `file://` |
| Blank results / parse error | Paste more content (JD > 100 chars, resume > 200 chars) |
| Score trend chart empty | Needs at least 2 analyses in history |
| File upload shows garbage | Only `.txt` files are supported (not PDF/DOCX) |
| Cover letter says "the candidate" | Enter your name in the "Your Full Name" field |

---

## 🛣 Future Roadmap

- [ ] PDF resume text extraction (PDF.js)
- [ ] DOCX support
- [ ] Side-by-side resume editor with real-time re-scoring
- [ ] Batch mode: one resume vs multiple JDs
- [ ] LinkedIn job URL auto-import
- [ ] Export analysis as formatted PDF report
- [ ] Dark/light theme toggle
- [ ] Multi-language support (Hindi, Marathi)

---

## 👨‍💻 Author

**Suraj Aher** — [github.com/Suraj-Aher](https://github.com/Suraj-Aher)

Smart Resume Analyzer · May 2025

---

## 📄 License

MIT License — free to use, modify, and distribute.
